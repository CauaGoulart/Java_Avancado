package carro;


public class Carro {
	String modelo;
	String cor;
	int ano;
}
