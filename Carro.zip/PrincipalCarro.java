package carro;

public class PrincipalCarro {

public static void main(String[] args) {
		
		Carro novoCarro = new Carro();
		novoCarro.modelo = "Onix";
		novoCarro.ano = 2019;
		novoCarro.cor = "Branco";
		
		Carro novoCarro2 = new Carro();
		novoCarro2.modelo = "Ford";
		novoCarro2.ano = 2004;
		novoCarro2.cor = "Azul";
		
		Carro novoCarro3 = new Carro();
		novoCarro3.modelo = "Fiat";
		novoCarro3.ano = 2001;
		novoCarro3.cor = "Roxo";
		
		System.out.println("A cor do primeiro carro é " + novoCarro.cor);
		System.out.println("A cor do segundo carro é " + novoCarro2.cor);
		System.out.println("A cor do terceiro carro é " + novoCarro3.cor);

	}
}
